% 2D coefficient matrix-vector multiplication
function A_x=mfun(x_v,M,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,tau,h,alpha,beta,kx1,kx2,ky1,ky2)

x= reshape(x_v,M,M); 
x= 1/8*(6*x + [x(2:end,:); zeros(1,M)] + [zeros(1,M); x(1:end-1,:)]);   %  (Iy tensor H_alpha )*x
x= 1/8 *(6*x + [x(:,2:end) zeros(M,1)] + [zeros(M,1) x(:,1:end-1)]);    %  (H_beta tensor Ix )*x

[w1,w2] = fun5(x_v,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,M,kx1,kx2,ky1,ky2);

w=(tau)/(2*gamma(alpha+1)*h^(2-alpha))*w1 + (tau)/(2*gamma(beta+1)*h^(2-beta))*w2;  

A_x= x(:) + w; 

end