function y = pfun(x,M,eig_M)

% step 1
z=reshape(x,M,M);
z=dst(z);  
z=dst(z');  
y=2/(M+1)* reshape(z',M^2,1);

% step 2
y=y./eig_M;

% step 3
z=reshape(y,M,M); 
z=dst(z);
z=dst(z');
y=2/(M+1)* reshape(z',M^2,1);

end




