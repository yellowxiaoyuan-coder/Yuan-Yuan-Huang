function [y1,y2] =  fun5(x,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,M,kx1,kx2,ky1,ky2)
x0=reshape(x,M,M);

%  (H_beta tensor (kx1*Gx_L+kx2*Gx_R) )*x
x_alpha=[x0;zeros(M,M)]; 
y1=real(ifft( repmat(kx1*eig_Gx_L_cir+kx2*eig_Gx_R_cir,1,M).* fft(x_alpha) ));
y1=y1(1:M,:);   %  (Iy tensor (kx1*Gx_L+kx2*Gx_R))*x
y1= 1/8 * (6*y1 + [y1(:,2:end) zeros(M,1)] + [zeros(M,1) y1(:,1:end-1)]);  % (H_beta tensor tensor (kx1*Gx_L+kx2*Gx_R))*x
y1=y1(:);


%  ((ky1*Gx_L+ky2*Gx_R) tensor H_alpha )*x
x0= 1/8 *(6*x0 + [x0(2:end,:); zeros(1,M)] + [zeros(1,M); x0(1:end-1,:)]) ;  % ((ky1*Gx_L+ky2*Gx_R) tensor Ix )*x
x_beta=[x0 zeros(M,M)]; %   
y2=real(ifft( repmat(ky1*eig_Gy_L_cir.'+ky2*eig_Gy_R_cir.',M,1).* fft(x_beta,[],2),[],2 ));  %((ky1*Gx_L+ky2*Gx_R) tensor H_alpha)*x 
y2=reshape(y2(:,1:M),M^2,1);

end
