function [time1,ave_iter,error]=direct(M,N,alpha,beta)

a=0;    
b=1;    
T=1;    

tau=T/N;   % temporal step size 

TOL = 1e-9;   % tolerance of PCG
maxit=M^2;

h=(b-a)/(M+1);   % spatial step size 
% hy=hx ;

% coefficients 
kx1=5;
kx2=5;
ky1=5;
ky2=5;


x=(1:M)'*h;  % the x-direction coordinates at the interior points 
y=x;         % the y-direction coordinates at the interior points 

% lower bounds of x
xl=zeros(M,1);
% xl(1)=hx/2;
  for i=1:M
  xl(i)=(i-1/2)*h;
  end

% upper bounds of x
xu=zeros(M,1);
for i=1:M
  xu(i)=(i+1/2)*h;
end


% lower bounds of y
yl=zeros(M,1);
for j=1:M
   yl(j)=(j-1/2)*h;
end

% upper bounds of y
 yu=zeros(M,1);
for j=1:M
  yu(j)=(j+1/2)*h;
end


%% generate coefficients s_alpha and s_beta

s0_alpha=(1/2)^alpha;    % s0
s_alpha=zeros(M,1);
s_alpha(1)=(3/2)^alpha-2*(1/2)^alpha; % s1
for k=2:M
    s_alpha(k)=(k+1/2)^alpha-2*(k-1/2)^alpha+(k-3/2)^alpha;  % s2��s_{n_i}
end

s0_beta=(1/2)^beta;
s_beta=zeros(M,1);
s_beta(1)=(3/2)^beta-2*(1/2)^beta;
for k=2:M
    s_beta(k)=(k+1/2)^beta-2*(k-1/2)^beta+(k-3/2)^beta;
end


% q0,q1,...q_n_i
qalpha=zeros(M+1,1);     
qalpha(1)=-s0_alpha;            % q_0
qalpha(2)=s0_alpha-s_alpha(1);  % q_1
for k=3:M+1
    qalpha(k)=s_alpha(k-2)-s_alpha(k-1);  % q_2 to q_{n_i}
end

qbeta=zeros(M+1,1);     
qbeta(1)=-s0_beta;    % q_0
qbeta(2)=s0_beta-s_beta(1);     % q_1
for k=3:M+1
    qbeta(k)=s_beta(k-2)-s_beta(k-1);     % q_2 to q_{n_i}
end


% eigenvalues of corresponding circulant matrices of left and right RL discretization matrices
eig_Gx_L_cir=fft([qalpha(2:end);zeros(M-1,1);qalpha(1)]);   
eig_Gx_R_cir=fft([qalpha(2);qalpha(1);zeros(M-1,1);qalpha(end:-1:3)]);  

eig_Gy_L_cir=fft([qbeta(2:end);zeros(M-1,1);qbeta(1)]);  
eig_Gy_R_cir=fft([qbeta(2);qbeta(1);zeros(M-1,1);qbeta(end:-1:3)]);   



%% the proposed preconditioner
Dc=zeros(M,1);   % first column of discrete sine matrix S_n  
for j=1:M
    Dc(j)=sqrt(2/(M+1))*sin((pi*j)/(M+1));      % first column of discrete sine matrix S_n  
end

H_alpha_col=[3/4; 1/8; zeros(M-2,1)];   % first column of H_alpha
H_beta_col=[3/4; 1/8; zeros(M-2,1)];    % first column of H_beta

eig_H_alpha= (1./Dc).*(sqrt(2/(M+1))*dst(H_alpha_col)) ;  % eigenvalues of tau(H_alpha)
eig_H_beta= (1./Dc).*(sqrt(2/(M+1))*dst(H_beta_col)) ;    % eigenvalues of tau(H_beta)


g_alpha_Riesz=1/2*[2*qalpha(2);qalpha(1)+qalpha(3);qalpha(4:end)]; % first column of H(T_alpha)
c_G_central_alpha = g_alpha_Riesz-[g_alpha_Riesz(3:end);0;0];      % first column of tau(H(T_alpha))
  
g_beta_Riesz=1/2*[2*qbeta(2);qbeta(1)+qbeta(3);qbeta(4:end)]; % first column of H(T_beta)
c_G_central_beta = g_beta_Riesz-[g_beta_Riesz(3:end);0;0];    % first column of tau(H(T_beta))

eig_tau_G_alpha=(1./Dc).*(sqrt(2/(M+1))*dst(c_G_central_alpha)); % eigenvalues of tau(H(T_alpha))
eig_tau_G_beta=(1./Dc).*(sqrt(2/(M+1))*dst(c_G_central_beta)); % eigenvalues of tau(H(T_beta))


% eigenvalues of the proposed preconditioner
eig_M = kron(eig_H_beta,eig_H_alpha) + (kx1+kx2)*tau/(2*gamma(alpha+1)*h^(2-alpha))*kron(eig_H_beta,eig_tau_G_alpha) + (ky1+ky2)*tau/(2*gamma(beta+1)*h^(2-beta))*kron(eig_tau_G_beta,eig_H_alpha); 


%% 
sum_iter=zeros(N,1);  % store the iteration numbers at each time level
x_temp =  kron(y.^2.*(1-y).^2,x.^2.*(1-x).^2); % temp

u_temp=reshape(x_temp,M,M);

u1=4*u_temp;  % u0


% source term related
f=@(xf,yf) -(yf.^2).*(1-yf).^2.*(gamma(5)/gamma(3+alpha)*(kx1*xf.^(2+alpha)+kx2*(1-xf).^(2+alpha))-2*gamma(4)/gamma(2+alpha)*(kx1*xf.^(1+alpha)+kx2*(1-xf).^(1+alpha))...
         +gamma(3)/gamma(1+alpha)*(kx1*xf.^(alpha)+kx2*(1-xf).^(alpha)))...
         -(xf.^2).*(1-xf).^2.*(gamma(5)/gamma(3+beta)*(ky1*yf.^(2+beta)+ky2*(1-yf).^(2+beta))-2*gamma(4)/gamma(2+beta)*(ky1*yf.^(1+beta)+ky2*(1-yf).^(1+beta))...
         +gamma(3)/gamma(1+beta)*(ky1*yf.^(beta)+ky2*(1-yf).^(beta)))...
         +xf.^2.*(1-xf).^2.*yf.^2.*(1-yf).^2;

fxy=zeros(M^2,1);
parfor idx=1:M^2
      j = floor((idx-1)/M) + 1;    
      i = mod(idx-1, M) + 1;    
     fxy(idx)=1/(h*h)*integral2(f,xl(i),xu(i),yl(j),yu(j));    
end

fxy=reshape(fxy,M^2,1); 


%%  start iteration
tic
for i=1:N
    
t1=(i-1/2)*tau;

RHS1 = 1/8*(6*u1 + [u1(2:end,:); zeros(1,M)] + [zeros(1,M); u1(1:end-1,:)]);   % (Iy tensor Hx)*x
RHS1 =  1/8*(6*RHS1 + [RHS1(:,2:end) zeros(M,1)] + [zeros(M,1) RHS1(:,1:end-1)]);   % (Hy tensor Hx)*x

[w1,w2] = fun5(u1,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,M,kx1,kx2,ky1,ky2);   % Toeplitz matrix vector multiplications
RHS2 = (tau)/(2*gamma(alpha+1)*h^(2-alpha))*w1 + (tau)/(2*gamma(beta+1)*h^(2-beta))*w2;  

RHS3=4*exp(t1)*fxy;   % source term

RHS = RHS1(:) - RHS2(:)  + tau * RHS3;  % final RHS

[u1,~,~,iter] = pcg(@(x_v) mfun(x_v,M,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,tau,h,alpha,beta,kx1,kx2,ky1,ky2), RHS, TOL, maxit, @(x) pfun(x,M,eig_M));

sum_iter(i) =iter;

u1=reshape(u1,M,M);  

end
time1=toc
ave_iter=mean(sum_iter)

x_true= 4*exp(1) * u_temp(:); % exact solution at t=1

%% L2 norm
error=sqrt(h^2*sum((x_true-u1(:)).^2)) 

end




