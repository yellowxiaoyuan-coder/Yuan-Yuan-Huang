clear
clc

disp('PGMRES_Hermitian_tau')


alpha_initial=[0.1;0.4;0.7;0.1];
beta_initial=[0.2;0.5;0.8;0.5];
gamma_initial=[0.3;0.6;0.9;0.9];



num1=length(alpha_initial);

  
  N_sq=2.^(2:5);    % time
  M_sq=2.^(3:6)-1;   % space
   num=length(M_sq); 
  num3=num1*num;
  


  
cputime=zeros(num3,1);
error_1=zeros(num3,1);
average_iter=zeros(num3,1);
conv_rate_space=zeros(num3,1);
conv_rate_time=zeros(num3,1);

for i_1=1:num1
     alpha=alpha_initial(i_1)
     beta=beta_initial(i_1)
     gam=gamma_initial(i_1)
for j=1:num
    g=j
    
 N=N_sq(j)
 M=M_sq(j)

 
[time1,ave_iter,error]=direct(M,N,alpha,beta,gam);

 error_1((i_1-1)*num+g)=error
 cputime((i_1-1)*num+g)=time1 
 average_iter((i_1-1)*num+g)=ave_iter

  if g>1
%   conv_rate_time((i_1-1)*num+g)=log(error_1((i_1-1)*num+g-1)/error_1((i_1-1)*num+g))/log(((N_sq(g))/N_sq(g-1)))
  conv_rate_space((i_1-1)*num+g)=log(error_1((i_1-1)*num+g-1)/error_1((i_1-1)*num+g))/log((M_sq(g)+1)/(M_sq(g-1)+1))
  end
 
end
end
% 
% Result=[error_1,cputime,average_iter,conv_rate_time]  % temporal convergence rate
% save('Ex_time.mat','Result')  

Result=[error_1,cputime,average_iter,conv_rate_space]   % spatial convergence rate
save('Ex_space.mat','Result')  



