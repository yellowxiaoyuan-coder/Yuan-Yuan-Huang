function [time1,ave_iter,error]=direct(M,N,alpha,beta,gam)



a=0;    
b=1;    
T=1;    

tau=T/N;   % temporal step size 


TOL = 1e-9;   % tolerance of PCG
maxit=M^3;

h=(b-a)/(M+1);   % spatial step size 
% hy=hx ;


% coefficients 
kx1=19;
kx2=21;
ky1=21;
ky2=23;
kz1=23;
kz2=25;


x=(1:M)'*h;   % x���������(�ڵ�)
y=x;   % x���������(�ڵ�)
z=x;

% lower bounds of x
xl=zeros(M,1);
% xl(1)=hx/2;
  for i=1:M
  xl(i)=(i-1/2)*h;
  end

% upper bounds of x
xu=zeros(M,1);
for i=1:M
  xu(i)=(i+1/2)*h;
end


% lower bounds of y
yl=zeros(M,1);
for j=1:M
   yl(j)=(j-1/2)*h;
end

% upper bounds of y
 yu=zeros(M,1);
for j=1:M
  yu(j)=(j+1/2)*h;
end

% lower bounds of z
zl=zeros(M,1);
for k=1:M
   zl(k)=(k-1/2)*h;
end

% upper bounds of z
 zu=zeros(M,1);
for k=1:M
  zu(k)=(k+1/2)*h;
end


%% generate coefficients s

s0_alpha=(1/2)^alpha;    % s0
s_alpha=zeros(M,1);
s_alpha(1)=(3/2)^alpha-2*(1/2)^alpha; % s1
for k=2:M
    s_alpha(k)=(k+1/2)^alpha-2*(k-1/2)^alpha+(k-3/2)^alpha;  % s2��s_{n_i}
end

s0_beta=(1/2)^beta;
s_beta=zeros(M,1);
s_beta(1)=(3/2)^beta-2*(1/2)^beta;
for k=2:M
    s_beta(k)=(k+1/2)^beta-2*(k-1/2)^beta+(k-3/2)^beta;
end


s0_gamma=(1/2)^gam;
s_gamma=zeros(M,1);
s_gamma(1)=(3/2)^gam-2*(1/2)^gam;
for k=2:M
    s_gamma(k)=(k+1/2)^gam-2*(k-1/2)^gam+(k-3/2)^gam;
end



%q0,q1,...q_n_i
qalpha=zeros(M+1,1);     
qalpha(1)=-s0_alpha;    % q_0
qalpha(2)=s0_alpha-s_alpha(1);     % q_1
for k=3:M+1
    qalpha(k)=s_alpha(k-2)-s_alpha(k-1);     % q_2 to q_{n_i}
end

qbeta=zeros(M+1,1);     
qbeta(1)=-s0_beta;    % q_0
qbeta(2)=s0_beta-s_beta(1);     % q_1
for k=3:M+1
    qbeta(k)=s_beta(k-2)-s_beta(k-1);      % q_2 to q_{n_i}
end


qgamma=zeros(M+1,1);     
qgamma(1)=-s0_gamma;    % q_0
qgamma(2)=s0_gamma-s_gamma(1);     % q_1
for k=3:M+1
    qgamma(k)=s_gamma(k-2)-s_gamma(k-1);     % q_2 to q_{n_i}
end


% eigenvalues of corresponding circulant matrices of left and right RL discretization matrices
eig_Gx_L_cir=fft([qalpha(2:end);zeros(M-1,1);qalpha(1)]);   
eig_Gx_R_cir=fft([qalpha(2);qalpha(1);zeros(M-1,1);qalpha(end:-1:3)]);  

eig_Gy_L_cir=fft([qbeta(2:end);zeros(M-1,1);qbeta(1)]);   
eig_Gy_R_cir=fft([qbeta(2);qbeta(1);zeros(M-1,1);qbeta(end:-1:3)]);   

eig_Gz_L_cir=fft([qgamma(2:end);zeros(M-1,1);qgamma(1)]);  
eig_Gz_R_cir=fft([qgamma(2);qgamma(1);zeros(M-1,1);qgamma(end:-1:3)]);   


%% Tau preconditioner

Dc=zeros(M,1);  % first column of discrete sine matrix S_n  
for j=1:M
    Dc(j)=sqrt(2/(M+1))*sin((pi*j)/(M+1));     % first column of discrete sine matrix S_n  
end

H_alpha_col=[3/4; 1/8; zeros(M-2,1)];   % first column of H_alpha
H_beta_col=[3/4; 1/8; zeros(M-2,1)];  % first column of H_beta
H_gamma_col=[3/4; 1/8; zeros(M-2,1)];   % first column of H_gamma

eig_H_alpha= (1./Dc).*(sqrt(2/(M+1))*dst(H_alpha_col)) ; % eigenvalues of tau(H_alpha)
eig_H_beta= (1./Dc).*(sqrt(2/(M+1))*dst(H_beta_col)) ;  % eigenvalues of tau(H_beta)
eig_H_gamma= (1./Dc).*(sqrt(2/(M+1))*dst(H_gamma_col)) ;  % eigenvalues of tau(H_gamma)


g_alpha_Riesz=1/2*[2*qalpha(2);qalpha(1)+qalpha(3);qalpha(4:end)]; % first column of H(T_alpha)
c_G_central_alpha = g_alpha_Riesz-[g_alpha_Riesz(3:end);0;0];  % first column of tau(H(T_alpha))

g_beta_Riesz=1/2*[2*qbeta(2);qbeta(1)+qbeta(3);qbeta(4:end)]; % first column of H(T_beta)
c_G_central_beta = g_beta_Riesz-[g_beta_Riesz(3:end);0;0];     % first column of tau(H(T_beta))

g_gamma_Riesz=1/2*[2*qgamma(2);qgamma(1)+qgamma(3);qgamma(4:end)]; % first column of H(T_gamma)
c_G_central_gamma = g_gamma_Riesz-[g_gamma_Riesz(3:end);0;0];     % first column of tau(H(T_gamma))



eig_tau_G_alpha=(1./Dc).*(sqrt(2/(M+1))*dst(c_G_central_alpha)); % eigenvalues of tau(H(T_alpha))
eig_tau_G_beta=(1./Dc).*(sqrt(2/(M+1))*dst(c_G_central_beta)); % eigenvalues of tau(H(T_beta))
eig_tau_G_gamma=(1./Dc).*(sqrt(2/(M+1))*dst(c_G_central_gamma));% eigenvalues of tau(H(T_gamma))


% eigenvalues of proposed preconditioner
eig_M = kron(eig_H_gamma,kron(eig_H_beta,eig_H_alpha)) + (kx1+kx2)*tau/(2*gamma(alpha+1)*h^(2-alpha))*kron(eig_H_gamma,kron(eig_H_beta,eig_tau_G_alpha)) + (ky1+ky2)*tau/(2*gamma(beta+1)*h^(2-beta))*kron(eig_H_gamma,kron(eig_tau_G_beta,eig_H_alpha)) + (kz1+kz2)*tau/(2*gamma(gam+1)*h^(2-gam))*kron(eig_tau_G_gamma,kron(eig_H_beta,eig_H_alpha));  % ����ϵ�������Ԥ������, ��Ϊϵ��w_alpha�������1/h^alpha��������ֻ��Ҫ����tau�Ϳ�����


%% 
sum_iter=zeros(N,1);    % store the iteration numbers at each time level
x_temp = kron(z.^2.*(1-z).^2, kron(y.^2.*(1-y).^2,x.^2.*(1-x).^2)); % temp


u_temp=reshape(x_temp,M,M,M);

u1=sin(1)*u_temp;  % u0



% source term related

f1=@(xf,yf,zf) xf.^2.*(1-xf).^2.*yf.^2.*(1-yf).^2.*zf.^2.*(1-zf).^2 ;
     
f2=@(xf,yf,zf) (yf.^2).*(1-yf).^2.*(zf.^2).*(1-zf).^2.*(gamma(5)/gamma(3+alpha)*(kx1*xf.^(2+alpha)+kx2*(1-xf).^(2+alpha))-2*gamma(4)/gamma(2+alpha)*(kx1*xf.^(1+alpha)+kx2*(1-xf).^(1+alpha))...
         +gamma(3)/gamma(1+alpha)*(kx1*xf.^(alpha)+kx2*(1-xf).^(alpha)))...
         +(xf.^2).*(1-xf).^2.*(zf.^2).*(1-zf).^2.*(gamma(5)/gamma(3+beta)*(ky1*yf.^(2+beta)+ky2*(1-yf).^(2+beta))-2*gamma(4)/gamma(2+beta)*(ky1*yf.^(1+beta)+ky2*(1-yf).^(1+beta))...
         +gamma(3)/gamma(1+beta)*(ky1*yf.^(beta)+ky2*(1-yf).^(beta)))...
         +(xf.^2).*(1-xf).^2.*(yf.^2).*(1-yf).^2.*(gamma(5)/gamma(3+gam)*(kz1*zf.^(2+gam)+kz2*(1-zf).^(2+gam))-2*gamma(4)/gamma(2+gam)*(kz1*zf.^(1+gam)+kz2*(1-zf).^(1+gam))...
         +gamma(3)/gamma(1+gam)*(kz1*zf.^(gam)+kz2*(1-zf).^(gam)));

fxyz1= zeros(M^3,1);
fxyz2= zeros(M^3,1);
parfor idx=1:M^3
    k = floor((idx-1)/M^2) + 1         
    j = floor(mod(idx-1, M^2)/M) + 1   
    i = mod(mod(idx-1, M^2), M) + 1            

    fxyz1(idx)=1/(h*h*h)*integral3(f1,xl(i),xu(i),yl(j),yu(j),zl(k),zu(k));    
    fxyz2(idx)=1/(h*h*h)*integral3(f2,xl(i),xu(i),yl(j),yu(j),zl(k),zu(k));   
end

fxyz1=reshape(fxyz1,M^3,1); 
fxyz2=reshape(fxyz2,M^3,1); 




%%  start iteration

tic
for i=1:N
   

t1=(i-1/2)*tau;


RHS1 = (1/8*(6*u1 + [u1(2:end,:,:); zeros(1,M,M)] + [zeros(1,M,M); u1(1:end-1,:,:)]));      % (Iz tensor Iy tensor Hx)*x
RHS1 = (1/8*(6*RHS1 + [RHS1(:,2:end,:) zeros(M,1,M)] + [zeros(M,1,M) RHS1(:,1:end-1,:)]));  % (Iz tensor Hy tensor Hx)*x
RHS1 = (1/8*(6*RHS1 + cat(3,RHS1(:,:,2:end), zeros(M,M,1)) + cat(3,zeros(M,M,1), RHS1(:,:,1:end-1))));  % (Hz tensor Hy tensor Hx)*x



[w1,w2,w3] = fun5(u1,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,eig_Gz_L_cir,eig_Gz_R_cir,M,kx1,kx2,ky1,ky2,kz1,kz2);   % Toeplitz matrix vector multiplications
RHS2 = (tau)/(2*gamma(alpha+1)*h^(2-alpha))*w1 + (tau)/(2*gamma(beta+1)*h^(2-beta))*w2   +   (tau)/(2*gamma(gam+1)*h^(2-gam))*w3; 


RHS3=cos(t1+1)*fxyz1 - sin(t1+1)*fxyz2;  % source term






RHS = RHS1(:) - RHS2(:)  + tau * RHS3;  % final RHS

[u1,~,~,iter] = gmres(@(x_v) mfun(x_v,M,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,eig_Gz_L_cir,eig_Gz_R_cir,tau,h,alpha,beta,gam,kx1,kx2,ky1,ky2,kz1,kz2), RHS, 20, TOL, maxit, @(x) pfun(x,M,eig_M));
sum_iter(i) =(iter(1)-1)*20+iter(2);



u1=reshape(u1,M,M,M); 


end
time1=toc
ave_iter=mean(sum_iter)


x_true= sin(2) * u_temp(:); % exact solution at t=1

%% L2 norm
error=sqrt(h^3*sum((x_true-u1(:)).^2)) 


end




