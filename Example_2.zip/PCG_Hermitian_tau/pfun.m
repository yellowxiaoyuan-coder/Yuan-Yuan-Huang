function y = pfun(x,M,eig_M)

% step 1
x=reshape(x,M,M^2);
x = dst(x);
x=x.';
x=reshape(x,M,M^2);
x = dst(x);
x=x.';
x=reshape(x,M,M^2);
x = dst(x);
x=x.';


% step 2
y = reshape(x,M^3,1)./eig_M;

% step 3
x=reshape(y,M,M^2);
x = dst(x);
x=x.';
x=reshape(x,M,M^2);
x = dst(x);
x=x.';
x=reshape(x,M,M^2);
x = dst(x);
x=x.';


% normalization
y =(2/(M+1))^3 * reshape(x,M^3,1);






end