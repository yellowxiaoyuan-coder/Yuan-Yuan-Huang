% 3D coefficient matrix-vector multiplication

function A_x=mfun(x_v,M,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,eig_Gz_L_cir,eig_Gz_R_cir,tau,h,alpha,beta,gam,kx1,kx2,ky1,ky2,kz1,kz2)

x= reshape(x_v,M,M,M);  

x = (1/8*(6*x + [x(2:end,:,:); zeros(1,M,M)] + [zeros(1,M,M); x(1:end-1,:,:)]));      % (Iz tensor Iy tensor Hx)*x

x = (1/8*(6*x + [x(:,2:end,:) zeros(M,1,M)] + [zeros(M,1,M) x(:,1:end-1,:)]));  % (Iz tensor Hy tensor Hx)*x

x = (1/8*(6*x + cat(3,x(:,:,2:end), zeros(M,M,1)) + cat(3,zeros(M,M,1), x(:,:,1:end-1)) ));  % (Hz tensor Hy tensor Hx)*x

[w1,w2,w3] = fun5(x_v,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,eig_Gz_L_cir,eig_Gz_R_cir,M,kx1,kx2,ky1,ky2,kz1,kz2);

w=(tau)/(2*gamma(alpha+1)*h^(2-alpha))*w1 + (tau)/(2*gamma(beta+1)*h^(2-beta))*w2 + (tau)/(2*gamma(gam+1)*h^(2-gam))*w3;  

A_x= x(:) + w;  

end