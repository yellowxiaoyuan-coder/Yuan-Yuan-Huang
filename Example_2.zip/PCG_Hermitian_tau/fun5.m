% fft
function [y1,y2,y3] =  fun5(x,eig_Gx_L_cir,eig_Gx_R_cir,eig_Gy_L_cir,eig_Gy_R_cir,eig_Gz_L_cir,eig_Gz_R_cir,M,kx1,kx2,ky1,ky2,kz1,kz2)

x0=reshape(x,M,M,M);

% (H_gamma tensor H_beta tensor (theta*Gx_L+(1-theta)*Gx_R) )*x
x_alpha=[x0;zeros(M,M,M)]; 
y1=real(  ifft( repmat(kx1*eig_Gx_L_cir+kx2*eig_Gx_R_cir,1,M,M).* fft(x_alpha,[],1),[],1 ));
y1=y1(1:M,:,:);   %  (Iz tensor Iy tensor (kx1*Gx_L+kx2*Gx_R) )*x
y1= 1/8*(6*y1 + [y1(:,2:end,:) zeros(M,1,M)] + [zeros(M,1,M) y1(:,1:end-1,:)]);  %  (Iz tensor H_beta tensor (kx1*Gx_L+kx2*Gx_R) )*x
y1= 1/8*(6*y1 + cat(3,y1(:,:,2:end), zeros(M,M,1)) + cat(3, zeros(M,M,1), y1(:,:,1:end-1))) ;  %  (H_gamma tensor H_beta tensor H_alpha )*x
y1=y1(:); 


% (H_gamma tensor (theta*Gy_L+(1-theta)*Gy_R) tensor H_alpha )*x
y2=1/8*(6*x0 + [x0(2:end,:,:); zeros(1,M,M)] + [zeros(1,M,M); x0(1:end-1,:,:)]) ;  %  (Iz tensor Iy tensor H_alpha )*x
x_beta=[y2 zeros(M,M,M)]; 
y2=real(ifft( repmat(ky1*eig_Gy_L_cir.'+ky2*eig_Gy_R_cir.',M,1,M).* fft(x_beta,[],2),[],2 ));  % (Iz tensor (ky1*Gy_L+ky2*Gy_R) tensor H_alpha)*x
y2=y2(:,1:M,:);   % (H_gamma tensor (ky1*Gy_L+ky2*Gy_R) tensor H_alpha )*x
y2= 1/8*(6*y2 + cat(3,y2(:,:,2:end), zeros(M,M,1)) + cat(3, zeros(M,M,1), y2(:,:,1:end-1))) ;  %  (H_gamma tensor Iy tensor H_alpha)*x
y2=y2(:);

% ((theta*Gz_L+(1-theta)*Gz_R) tensor H_beta tensor H_alpha )*x
y3= 1/8*(6*x0 + [x0(2:end,:,:); zeros(1,M,M)] + [zeros(1,M,M); x0(1:end-1,:,:)]) ;  % (Iz tensor Iy tensor H_alpha)*x
y3= 1/8*(6*y3 + [y3(:,2:end,:) zeros(M,1,M)] + [zeros(M,1,M) y3(:,1:end-1,:)]); % (Iz tensor H_beta tensor H_alpha)*x
x_gamma=cat(3,y3, zeros(M,M,M));
y3=real(ifft( repmat(kz1*permute(eig_Gz_L_cir,[2 3 1])+kz2*permute(eig_Gz_R_cir,[2 3 1]),M,M,1).* fft(x_gamma,[],3),[],3 ));  % ((ky1*Gy_L+ky2*Gy_R) tensor H_alpha)*x 
y3=y3(:,:,1:M);
y3=y3(:);


end
