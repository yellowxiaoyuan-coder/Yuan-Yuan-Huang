% 1D coefficient matrix-vector multiplication
function A_x=mfun(x_v,M,eig_Gx_L_cir,eig_Gx_R_cir,tau,h,alpha,kx1,kx2)



x= 1/8*(6*x_v + [x_v(2:end);0] + [0; x_v(1:end-1)]);  %  H_alpha  *x



w1 = fun5(x_v,eig_Gx_L_cir,eig_Gx_R_cir,M,kx1,kx2);

w=(tau)/(2*gamma(alpha+1)*h^(2-alpha))*w1;  



A_x= x + w; 

end