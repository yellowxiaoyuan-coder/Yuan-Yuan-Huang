% fft
function y = fun5(x,eig_Gx_L_cir,eig_Gx_R_cir,M,kx1,kx2)
x_alpha=[x;zeros(M,1)]; 
y1=real(ifft(eig_Gx_L_cir.* fft(x_alpha)));
y1=kx1.*y1(1:M);  
y2=real(ifft( eig_Gx_R_cir.* fft(x_alpha)));
y2=kx2.*y2(1:M);  
y= y1+y2;
end
