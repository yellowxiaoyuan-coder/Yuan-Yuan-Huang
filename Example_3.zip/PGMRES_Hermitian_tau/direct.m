function [time1,ave_iter,error]=direct(M,N,alpha)

a=0;    
b=1;    
T=1;    

tau=T/N;   % temporal step size 

TOL = 1e-9;   % tolerance of PGMRES

maxit=M^2;

h=(b-a)/(M+1);   % spatial step size 

x=(1:M)'*h;    

% lower bounds of x
xl=zeros(M,1);
% xl(1)=hx/2;
  for i=1:M
  xl(i)=(i-1/2)*h;
  end

% upper bounds of x
xu=zeros(M,1);
for i=1:M
  xu(i)=(i+1/2)*h;
end


% variable coefficients (diagonal matrix) stored by two columns
kx1= 1+sin(pi*xl)/2;  
kx2= 1+sin(pi*xu)/2;  

% averaged-coefficient for the proposed preconditioner
bar_kx1=mean(kx1);  
bar_kx2=mean(kx2);  


%% generate the coefficients s_alpha
s0_alpha=(1/2)^alpha;    % s0
s_alpha=zeros(M,1);
s_alpha(1)=(3/2)^alpha-2*(1/2)^alpha; % s1
for k=2:M
    s_alpha(k)=(k+1/2)^alpha-2*(k-1/2)^alpha+(k-3/2)^alpha;  % s2 to s_{n_i}
end

% q0,q1,...q_n_i
qalpha_col=zeros(M,1);  
qalpha_row=zeros(M,1); 

qalpha_col(1)=s0_alpha-s_alpha(1);    
qalpha_col(2)=s_alpha(1)-s0_alpha;    
for k=3:M
    qalpha_col(k)=s_alpha(k-1);    
end

qalpha_row(1)=s0_alpha-s_alpha(1);    
for k=2:M
    qalpha_row(k)=-s_alpha(k);     
end


% eigenvalues of corresponding circulant matrices of left and right RL discretization matrices
eig_Gx_L_cir=fft([qalpha_col;0;qalpha_row(end:-1:2)]);  
eig_Gx_R_cir=fft([qalpha_row;0;qalpha_col(end:-1:2)]);  


%% The proposed preconditioner
Dc=zeros(M,1);   
for j=1:M
    Dc(j)=sqrt(2/(M+1))*sin((pi*j)/(M+1));   % first column of discrete sine matrix S_n  
end

% first column of tridiagonal matrix
H_alpha_col=[3/4; 1/8; zeros(M-2,1)];   

% eigenvalues of tau(H_alpha)
eig_H_alpha= (1./Dc).*(sqrt(2/(M+1))*dst(H_alpha_col)); 

% first column of H(T_alpha)
g_alpha_Riesz=1/2*(qalpha_col+qalpha_row);  

% first column of tau(H(T_alpha))
c_G_central_alpha = g_alpha_Riesz-[g_alpha_Riesz(3:end);0;0];   

% eigenvalues of tau(H(T_alpha))
eig_tau_G_alpha=(1./Dc).*(sqrt(2/(M+1))*dst(c_G_central_alpha));

% eigenvalues of the proposed preconditioner
eig_M = eig_H_alpha + (bar_kx1+bar_kx2)*tau/(2*gamma(alpha+1)*h^(2-alpha))*eig_tau_G_alpha;  


%% 
sum_iter=zeros(N,1);   % store the iteration numbers at each time level
x_temp =  x.^2.*(1-x).^2; % temp

u1=x_temp;  % u0

% source term related
f=@(xf) -pi*cos(pi*xf)./2.*(gamma(3)/gamma(2+alpha)*(xf.^(1+alpha)-(1-xf).^(1+alpha))-2*gamma(4)/gamma(3+alpha)*(xf.^(2+alpha)-(1-xf).^(2+alpha))...
         +gamma(5)/gamma(4+alpha)*(xf.^(3+alpha)-(1-xf).^(3+alpha)))...
         -(1+sin(pi*xf)./2).*(gamma(3)/gamma(1+alpha)*(xf.^(alpha)+(1-xf).^(alpha))-2*gamma(4)/gamma(2+alpha)*(xf.^(1+alpha)+(1-xf).^(1+alpha))...
         +gamma(5)/gamma(3+alpha)*(xf.^(2+alpha)+(1-xf).^(2+alpha)))...
         +xf.^2.*(1-xf).^2;
     
fxy=zeros(M,1);

parfor idx=1:M
     fxy(idx)=1/h*integral(f,xl(idx),xu(idx)); 
end


%%  start iteration
tic
for i=1:N
t1=(i-1/2)*tau;
RHS1 = 1/8*(6*u1 + [u1(2:end); 0] + [0; u1(1:end-1)]);     %  tridiagonal matrix-vector multiplication
w1 = fun5(u1,eig_Gx_L_cir,eig_Gx_R_cir,M,kx1,kx2);    % Toeplitz matrix-vector multiplication
RHS2 = (tau)/(2*gamma(alpha+1)*h^(2-alpha))*w1 ;
RHS3=exp(t1)*fxy;   % source term
RHS = RHS1 - RHS2  + tau * RHS3;  % final RHS
[u1,~,~,iter] = gmres(@(x_v) mfun(x_v,M,eig_Gx_L_cir,eig_Gx_R_cir,tau,h,alpha,kx1,kx2), RHS, 20, TOL, maxit, @(x) pfun(x,M,eig_M));
sum_iter(i) =(iter(1)-1)*20+iter(2);
end
time1=toc
ave_iter=mean(sum_iter)

% exact solution at t=1
x_true= exp(1) * x_temp; 



%% L2 norm
error=sqrt(h*sum((x_true-u1(:)).^2)) 

end




