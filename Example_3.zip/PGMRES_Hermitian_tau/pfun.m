function y = pfun(x,M,eig_M)
y = 2/(M+1)*dst(dst(x)./eig_M);
end